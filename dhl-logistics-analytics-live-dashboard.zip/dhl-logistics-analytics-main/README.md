# DHL Express Business Analytics Project

## BAN6800 – Business Analytics

### Predictive Delivery Performance and Route Optimization

**Student:** Akpevwe Peters

## Project Overview

This project develops a business analytics solution for DHL Express to improve delivery performance by identifying shipments at risk of delay and supporting operational decision-making.

## Business Problem

DHL Express operates in an environment affected by changing shipment volumes, traffic, weather conditions, route complexity, operational capacity, and other factors.

Late deliveries can increase operating costs and customer-service workloads.

## Proposed Solution

The project combines:

- Predictive analytics
- Prescriptive analytics
- Risk scoring
- Explainability
- Operational dashboards
- Human-in-the-loop decision support

## Objectives

1. Predict shipment delivery delays.
2. Identify high-risk shipments.
3. Support exception management.
4. Support route and resource decisions.
5. Monitor delivery-performance KPIs.
6. Improve operational decision-making.
7. Maintain privacy, fairness, security, and accountability.

## Technology Stack

- Python
- pandas
- NumPy
- SQL
- scikit-learn
- Power BI / Tableau
- Docker
- GitHub
- Jupyter Notebook

## Project Structure

```text
dhl-logistics-analytics/
├── README.md
├── docs/
├── data/
├── notebooks/
├── src/
├── dashboard/
├── tests/
├── models/
├── requirements.txt
└── Dockerfile

## Interactive Streamlit Dashboard

The repository now includes a complete interactive dashboard backed by an XGBoost delay-risk model.

### Local setup

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python src/train_model.py
streamlit run dashboard/app.py
```

Open `http://localhost:8501`.

### Dashboard pages

- **Executive Overview** – KPI cards, hub delay rates, outcome distribution, and risk queue.
- **Shipment Investigator** – shipment-level XGBoost prediction and SHAP feature-impact explanation.
- **What-If Simulator** – live model predictions as weather, traffic, transit time, service tier, distance, and weight are changed.
- **Fairness & Ethics** – Fairlearn false-negative-rate analysis by hub plus governance controls.

### Docker

```bash
docker build -t dhl-logistics-dashboard .
docker run -p 8501:8501 dhl-logistics-dashboard
```

The Docker image trains the included reproducible synthetic demonstration model during build. Replace `data/processed/shipment_features.csv` with approved operational data and retrain before production use.
