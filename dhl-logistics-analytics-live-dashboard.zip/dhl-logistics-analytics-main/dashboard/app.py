"""Interactive DHL delivery-risk dashboard."""
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / "models" / "xgboost_model.pkl"
DATA = ROOT / "data" / "processed" / "shipment_features.csv"
METRICS = ROOT / "models" / "metrics.json"

st.set_page_config(page_title="DHL Logistics Analytics", page_icon="📦", layout="wide")

@st.cache_resource
def load_model(): return joblib.load(MODEL)
@st.cache_data
def load_data(): return pd.read_csv(DATA)
@st.cache_data
def load_metrics(): return json.loads(METRICS.read_text())

if not MODEL.exists() or not DATA.exists():
    st.error("Model/data artifacts are missing. Run: python src/train_model.py")
    st.stop()

model, df, metrics = load_model(), load_data(), load_metrics()
FEATURES = joblib.load(ROOT / "models" / "feature_columns.pkl")

st.sidebar.title("DHL Analytics")
page = st.sidebar.radio("Dashboard", ["Executive Overview", "Shipment Investigator", "What-If Simulator", "Fairness & Ethics"])
st.sidebar.caption("Human-in-the-loop decision support")

def encode(hub, service, planned, actual, weather, traffic, distance, weight):
    return pd.DataFrame([{
        "planned_transit_hours": planned, "actual_transit_hours": actual,
        "weather_severity_index": weather, "traffic_density": traffic,
        "route_distance_km": distance, "package_weight_kg": weight,
        "service_tier_code": {"Standard":0,"Express":1,"SameDay":2}[service]
    }])[FEATURES]

def risk_label(p):
    return "CRITICAL" if p >= .70 else "ELEVATED" if p >= .40 else "LOW"

if page == "Executive Overview":
    st.title("📊 DHL Logistics Analytics")
    st.subheader("Predictive Delivery Performance & Route Optimization")
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Total Shipments", f"{len(df):,}")
    c2.metric("Observed Delays", f"{df.is_delayed.sum():,}", f"{df.is_delayed.mean()*100:.1f}%")
    c3.metric("Delay Recall", f"{metrics['recall']*100:.1f}%")
    c4.metric("ROC-AUC", f"{metrics['roc_auc']:.3f}")
    left,right = st.columns(2)
    with left:
        counts = df.assign(risk=df.is_delayed.map({0:"On-Time",1:"Delayed"})).risk.value_counts().rename_axis("Status").reset_index(name="Shipments")
        st.plotly_chart(px.pie(counts, names="Status", values="Shipments", title="Observed Delivery Outcomes"), use_container_width=True)
    with right:
        hubs = df.groupby("origin_hub", as_index=False).agg(Shipments=("shipment_id","count"), Delay_Rate=("is_delayed","mean"))
        hubs["Delay_Rate"] *= 100
        st.plotly_chart(px.bar(hubs, x="origin_hub", y="Delay_Rate", title="Observed Delay Rate by Origin Hub", labels={"origin_hub":"Hub","Delay_Rate":"Delay rate (%)"}), use_container_width=True)
    st.subheader("Recent Shipment Risk Queue")
    q = df.copy(); q["risk_probability"] = model.predict_proba(q[FEATURES])[:,1]; q["risk"] = q.risk_probability.map(risk_label)
    q = q.sort_values("risk_probability", ascending=False)
    st.dataframe(q[["shipment_id","origin_hub","destination_hub","service_tier","risk_probability","risk"]].head(25), use_container_width=True)

elif page == "Shipment Investigator":
    st.title("🔎 Single-Shipment Investigator")
    shipment = st.selectbox("Shipment ID", df.shipment_id.tolist())
    r = df.loc[df.shipment_id == shipment].iloc[0]
    X = r[FEATURES].to_frame().T
    p = float(model.predict_proba(X)[0,1])
    st.metric("Delay Probability", f"{p*100:.1f}%", risk_label(p))
    c1,c2,c3 = st.columns(3); c1.metric("Origin",r.origin_hub); c2.metric("Destination",r.destination_hub); c3.metric("Service",r.service_tier)
    st.subheader("Shipment Inputs")
    st.dataframe(r[["planned_transit_hours","actual_transit_hours","weather_severity_index","traffic_density","route_distance_km","package_weight_kg"]].to_frame("Value"), use_container_width=True)
    st.subheader("SHAP Explanation")
    try:
        import shap
        explainer = shap.TreeExplainer(model)
        sv = explainer(X)
        values = sv.values[0]
        explanation = pd.DataFrame({"Feature": FEATURES, "Impact": values, "Absolute Impact": np.abs(values)}).sort_values("Absolute Impact", ascending=False)
        fig = px.bar(explanation.sort_values("Impact"), x="Impact", y="Feature", orientation="h", title="Local Feature Impact")
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(explanation[["Feature","Impact"]], use_container_width=True)
    except Exception as e:
        st.warning(f"SHAP explanation unavailable: {e}")

elif page == "What-If Simulator":
    st.title("🎛 What-If Scenario Simulator")
    base = df.iloc[0]
    c1,c2 = st.columns(2)
    with c1:
        service = st.selectbox("Service Tier", ["Standard","Express","SameDay"], index=1)
        planned = st.slider("Planned Transit (hours)", 4.0, 72.0, float(base.planned_transit_hours), .5)
        actual = st.slider("Current/Projected Transit (hours)", 4.0, 110.0, float(base.actual_transit_hours), .5)
        weather = st.slider("Weather Severity", 0.0, 1.0, float(base.weather_severity_index), .01)
    with c2:
        traffic = st.slider("Traffic Density", 0.0, 1.0, float(base.traffic_density), .01)
        distance = st.slider("Route Distance (km)", 50.0, 4500.0, float(base.route_distance_km), 10.0)
        weight = st.slider("Package Weight (kg)", .5, 40.0, float(base.package_weight_kg), .5)
    X = encode(base.origin_hub, service, planned, actual, weather, traffic, distance, weight)
    p = float(model.predict_proba(X)[0,1])
    st.divider(); st.metric("Live Model Risk", f"{p*100:.1f}%", risk_label(p))
    if p >= .70: st.error("CRITICAL — high predicted delay risk")
    elif p >= .40: st.warning("ELEVATED — moderate predicted delay risk")
    else: st.success("LOW — lower predicted delay risk")
    st.caption("The score is produced by the trained XGBoost model; changing a control reruns the model.")

else:
    st.title("⚖ Fairness & Ethical AI")
    try:
        from fairlearn.metrics import MetricFrame, false_negative_rate
        q = df.copy(); q["prediction"] = (model.predict_proba(q[FEATURES])[:,1] >= metrics["threshold"]).astype(int)
        mf = MetricFrame(metrics=false_negative_rate, y_true=q.is_delayed, y_pred=q.prediction, sensitive_features=q.origin_hub)
        result = mf.by_group.reset_index(); result.columns=["Hub","False Negative Rate"]
        result["False Negative Rate"] *= 100
        result["Sample %"] = q.origin_hub.value_counts(normalize=True).reindex(result.Hub).values * 100
        st.dataframe(result, use_container_width=True)
        st.plotly_chart(px.bar(result, x="Hub", y="False Negative Rate", title="False Negative Rate by Hub", labels={"False Negative Rate":"FNR (%)"}), use_container_width=True)
    except Exception as e:
        st.warning(f"Fairlearn metrics unavailable: {e}")
    st.subheader("Governance Controls")
    st.info("Human approval remains required for operational escalation.")
    st.info("Monitor model/data drift and revalidate when performance deteriorates.")
    st.info("Use anonymized operational data and minimize personal identifiers.")
