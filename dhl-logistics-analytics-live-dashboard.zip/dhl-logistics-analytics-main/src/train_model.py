"""Train the DHL delay-risk XGBoost model and save artifacts for the dashboard."""
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from xgboost import XGBClassifier

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "models"
DATA_DIR.mkdir(exist_ok=True)
MODEL_DIR.mkdir(exist_ok=True)

FEATURES = [
    "planned_transit_hours", "actual_transit_hours", "weather_severity_index",
    "traffic_density", "route_distance_km", "package_weight_kg", "service_tier_code"
]
CATEGORICAL = ["origin_hub", "destination_hub", "service_tier"]
HUBS = ["HUB_US", "HUB_EU", "HUB_APAC", "HUB_LATAM"]
SERVICES = ["Express", "Standard", "SameDay"]


def make_dataset(n=5500, seed=42):
    rng = np.random.default_rng(seed)
    origin = rng.choice(HUBS, n, p=[.42, .35, .15, .08])
    destination = rng.choice(HUBS, n)
    service = rng.choice(SERVICES, n, p=[.50, .40, .10])
    planned = rng.uniform(12, 72, n)
    weather = rng.beta(2.0, 4.0, n)
    traffic = rng.beta(2.2, 2.8, n)
    distance = rng.uniform(50, 4500, n)
    weight = rng.lognormal(2.0, .55, n).clip(0.5, 40)
    tier_code = pd.Series(service).map({"Standard": 0, "Express": 1, "SameDay": 2}).to_numpy()
    upstream_delay = rng.normal(0, 7, n)
    actual = (planned + upstream_delay + weather * 15 + traffic * 10 - tier_code * 1.5).clip(4, 110)
    hub_risk = pd.Series(origin).map({"HUB_US": .00, "HUB_EU": .02, "HUB_APAC": .04, "HUB_LATAM": .10}).to_numpy()
    # Synthetic target: deliberately strong, explainable signal for a runnable demo.
    # This is not operational DHL data and must be replaced with approved labels in production.
    score = (2.7 * weather + 2.2 * traffic + 0.075 * (actual - planned)
             + .00010 * distance + .035 * weight + .55 * (tier_code == 2)
             + hub_risk + rng.normal(0, .12, n))
    cutoff = np.quantile(score, .82)
    delayed = (score >= cutoff).astype(int)
    return pd.DataFrame({
        "shipment_id": [f"DHL-{100000+i}" for i in range(n)],
        "origin_hub": origin, "destination_hub": destination, "service_tier": service,
        "planned_transit_hours": planned.round(2), "actual_transit_hours": actual.round(2),
        "weather_severity_index": weather.round(4), "traffic_density": traffic.round(4),
        "route_distance_km": distance.round(1), "package_weight_kg": weight.round(2),
        "service_tier_code": tier_code, "is_delayed": delayed
    })


def main():
    df = make_dataset()
    csv_path = DATA_DIR / "processed" / "shipment_features.csv"
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(csv_path, index=False)

    X = df[FEATURES]
    y = df["is_delayed"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.20, stratify=y, random_state=42)
    pos = max(y_train.sum(), 1)
    neg = max(len(y_train) - y_train.sum(), 1)
    model = XGBClassifier(
        n_estimators=300, max_depth=5, learning_rate=.05, subsample=.85,
        colsample_bytree=.85, objective="binary:logistic", eval_metric="logloss",
        random_state=42, n_jobs=2, scale_pos_weight=float(neg / pos)
    )
    model.fit(X_train, y_train)
    prob = model.predict_proba(X_test)[:, 1]
    pred = (prob >= .40).astype(int)
    metrics = {
        "accuracy": accuracy_score(y_test, pred), "precision": precision_score(y_test, pred, zero_division=0),
        "recall": recall_score(y_test, pred, zero_division=0), "f1": f1_score(y_test, pred, zero_division=0),
        "roc_auc": roc_auc_score(y_test, prob), "confusion_matrix": confusion_matrix(y_test, pred).tolist(),
        "threshold": .40, "test_size": len(y_test)
    }
    joblib.dump(model, MODEL_DIR / "xgboost_model.pkl")
    joblib.dump(FEATURES, MODEL_DIR / "feature_columns.pkl")
    with open(MODEL_DIR / "metrics.json", "w") as f: json.dump(metrics, f, indent=2)
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
