from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def test_project_files_exist():
    assert (ROOT / "dashboard/app.py").exists()
    assert (ROOT / "src/train_model.py").exists()
    assert (ROOT / "requirements.txt").exists()
    assert (ROOT / "Dockerfile").exists()

def test_metrics_artifact():
    metrics = json.loads((ROOT / "models/metrics.json").read_text())
    assert 0 <= metrics["accuracy"] <= 1
    assert 0 <= metrics["recall"] <= 1
    assert 0 <= metrics["roc_auc"] <= 1
